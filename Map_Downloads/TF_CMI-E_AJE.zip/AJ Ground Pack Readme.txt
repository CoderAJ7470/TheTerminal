# AJ Ground Pack #

BATCH 41GPRev4

Includes :
1. AMF Abel Maintenance Facility Hangar
2. Symphony of CMI - CMI Class Ship