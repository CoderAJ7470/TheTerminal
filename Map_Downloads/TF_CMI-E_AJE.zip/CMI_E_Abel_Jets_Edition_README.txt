Thank you for downloading Central Mediterranean Islands Extended - Abel Jets Edition.

Many thanks to both FreezingFalcon and ThomasCook221 for their collective input. Their comprehensive feedback and inputs for the map (and patience) helped to see this to fruition, wouldn't have been possible without that :).

To install the map:

1. Drag and drop the file named sceTF_CMI-E_AJE.lst into your YS FLIGHT scenery folder.
2. Drag and drop the folder named TF_CMI-E_AJE into your user folder.

There are two stand-alone ground objects in this version - the Symphony of CMI and the Abel Maintenance Facility. To ensure they are present when you spawn in the map, you'll have to take just two more simple steps:
1. Drag and drop the file named "gro_AJVATESTAMFSHIP.lst" into your YS FLIGHT "ground" folder -> This is located inside the Ground folder included in the .zip
2. Make sure the folder named "AJVA" inside "Ground" is in your YS Flight "user" folder. If you already have the "AJVA" folder in you YS FLIGHT "user" folder, then just move the contents (SymphonyCMI and AMF folders) into your existing "AJVA" folder. If any of this does not make sense or is confusing, send me a pm/message me in Discord and I'll help you out.

Credits:
- PMNV [url=https://sites.google.com/site/yspmnv/files/pmnvgroundpack.zip?attredirects=0]ground objects pack[/url] (Over 80% of all ground objects are from this pack)
- TF 58's [url=https://forum.ysfhq.com/viewtopic.php?f=168&t=10462]ground objects[/url] (you'll need at least the ground objects from this pack but I highly suggest you install the whole pack if you don't have it)
- Airbourne's [url=https://forum.ysfhq.com/viewtopic.php?t=2616#p32975]ground objects pack[/url]
- KZS [url=http://mrsandj.sakura.ne.jp/ht/ckp/Kzs%20Pack/Kzspack.html]ground objects[/url] (I believe it's the S and M packs you need from this page)
- HotelFox's [url=https://forum.ysfhq.com/viewtopic.php?t=7157#p82334]ground objects pack[/url]
- Abel Jets Virtual Group: Symphony of CMI and Abel Maintenance Facility (included with this pack)

=======================================================
=======================================================

Some fast facts about the latest version of the Central Mediterranean Islands Extended map:

- Now with more than 470 start positions
- More than 200 gates between new Terminals 1 and 2, and the new Abel Jets Platinum Terminal at Mandiola International Airport (MXA)
- MXA is now home to the "Abel Jets Superhub" with a total of 155 gates + 6 Platinum Terminal gates that can accomodate upto Code F category aircraft
- 150 airline gates spread across 5 concourses and 6 Concourse C hardstands at Linbury International Airport (LNB)
- New fourth runway 18R-36L at MXA and new parallel runway 07R-25L at LNB
- New Abel Jets Virtual Group World Headquarters in Downtown Mandiola | 600 feet (183m), 50-storey One Abel Jets Place | 360 feet (110m), 30-storey Two Abel Jets Place | Equipped with a helipad
- New MXA ATC Tower | 400 feet (122m)
- Complete redesign of terminal road systems and approach roads at both, MXA and LNB
- New landside terminals at both, MXA and LNB
- Super-sized floating city, Symphony of CMI on a motion path around the original three islands, Turbot, Linbury and Ocaso - provided by Abel Jets Virtual Group (AJVG)
- Massive new Abel Maintenance Facility (AMF) at LNB - also provided by AJVG
- New four-storey AJVG World Operations Center in Linbury
- Re-built Island Central Expressway (ICE) on Winnsworth Island to accomodate expanded LNB
- Improved sky colour

With this release also comes a new but simple gate identification system for pilots, only at MXA and LNB. The system is as follows:

Airport Code_Terminal Number (if required)_gate number by concourse_ICAO aircraft code

So for example:
MXA_T1_A14_E means the gate is at MXA, Terminal 1, Concourse A gate #14 and can accomodate any aircraft with a wingspan upto Code E category

A similar numbering scheme is used at LNB.

=======================================================
=======================================================

MODIFICATION POLICY:

Please see the mod policy for all of my maps here: https://forum.ysfhq.com/viewtopic.php?p=113396#p113396

Also, since this version of the map is exclusively for Abel Jets Virtual Group, I am officially handing the "keys" to this version to Abel Jets Virtual Group (AJVG) with full permissions to make any modifications as wanted/needed.

If you want to modify this map, please keep in mind you may have to verify you have permission with FreezingFalcon and ThomasCook221, President and Vice-President of AJVG respectively as the group now has full ownership of this version of CMI-E.